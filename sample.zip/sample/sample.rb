def hello
  p "hello, world."
end

hello